.. code:: c

    # test
    void test ()

.. image:: test.png

.. parsed-literal::

    Warning message:
    “Test message”
